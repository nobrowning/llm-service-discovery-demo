# LLM API discovery core

Reusable Node.js mDNS/DNS-SD discovery and protocol helpers for `_llm-api._tcp.local`. This package has no Harness, Docker, Mock API, credentials, or UI dependency. It implements the experimental discovery profile used by the local LLM discovery demo; it is not a claim of complete RFC or draft conformance.

## Develop and package

Requires Node.js 22 or later. Node.js 24 is used by CI.

```sh
npm ci --ignore-scripts
npm test
npm pack
```

This checkout is independently installable. Until an npm release is published, consumers can install the generated tarball with `npm install /path/to/llm-discovery-discovery-core-0.2.0.tgz`. No published npm package or public repository URL is assumed.

## Discover services

```js
import { createDiscoveryClient } from '@llm-discovery/discovery-core';

const client = createDiscoveryClient({
  interfaceAddress: '192.168.1.20', // An IPv4 address attached to this client.
  networkId: 'office-lan',
});
const unsubscribe = client.subscribe(event => {
  if (event.type === 'added' || event.type === 'updated') {
    console.log(event.candidate.displayName, event.candidate.baseURL);
  }
});
await client.start();

// On application shutdown:
process.once('SIGINT', async () => {
  unsubscribe();
  await client.stop();
});
```

The selected interface must support multicast. This library does not alter firewall, routing, or system DNS settings. If no interface is supplied, it selects the first eligible non-loopback IPv4 interface; applications with multiple adapters should select one explicitly.

`snapshot()` returns the current candidates. `subscribe()` receives discovery, removal, validation, and network warnings. `stop()` closes the socket and timers. `query()` requests a refresh. Candidate state includes the network attachment, resolved addresses, expiration, validation, and a record generation so clients can reject stale selections.

## Protocol helpers

The root export also provides `SERVICE_TYPE`, `serviceRecords`, `parseTxt`, `candidateFromRecords`, and validation helpers. For record-only use:

```js
import { serviceRecords } from '@llm-discovery/discovery-core/protocol';
```

Publishing services belongs in the separate advertiser package. HTTPS trust, authorization, model/capability inspection, and inference belong in the consuming client. DNS-SD records are untrusted hints and do not authorize connecting to an API or sending credentials.

The network client currently uses IPv4 multicast. It can retain A and AAAA records, but that does not constitute verified IPv6 transport or cross-subnet discovery support. The deterministic tests here do not open multicast sockets; live network and interoperability checks are maintained in the demo repository.

## 中文说明

这是可独立复用的局域网 LLM API 发现库，负责 mDNS/DNS-SD 浏览、记录校验、缓存与服务生命周期。它不依赖 Harness、Docker 或演示模型，也不读取凭据或修改系统网络设置。

运行 `npm ci --ignore-scripts`、`npm test`、`npm pack` 即可安装依赖、测试和生成独立安装包。尚未发布 npm 时可直接安装生成的 `.tgz`。多网卡机器应通过 `interfaceAddress` 明确选择客户端 IPv4 地址。

公告功能位于单独的 advertiser 模块；HTTPS 信任、认证和推理由客户端实现。发现记录只是未受信任的服务线索，不能直接当作授权。真实网络互通验收保存在独立 Demo 仓库。

MIT License. See [LICENSE](LICENSE).
