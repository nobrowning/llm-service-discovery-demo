# Service integration contract

The plugin discovers `_llm-api._tcp.local` records using the discovery core. It currently connects only the `openresponses` profile with binding version `2026-04-24`. Announcement makes an endpoint visible; it does not establish trust or add an API implementation to a server.

## HTTP interface

Implement these authenticated HTTPS routes under the announced `base` path:

- `GET /models`: `{ "object": "list", "data": [{ "id": "my-model", "name": "My model" }] }`.
- `GET /_llm/capabilities`: the experimental metadata below. This route and schema are this project's extension, not standardized by the discovery draft.
- `POST /responses`: streaming text Responses events, with image input and function calls only when declared. See the adapter source for the supported event subset. Nonstream-only services can be inspected but cannot be connected by this adapter.

```json
{
  "schema": "llm-api-discovery-capabilities/v1",
  "revision": "1",
  "cache_max_age_seconds": 60,
  "mock": false,
  "node_label": "workstation.local",
  "models": [{
    "id": "my-model",
    "display_name": "My model",
    "input_modalities": ["text"],
    "output_modalities": ["text"],
    "streaming": "supported",
    "function_calling": "unsupported"
  }]
}
```

`models[].id` must also appear in `/models`. Optional `deployment` contains string fields `parameters`, `quantization` (or precision, e.g. BF16), and `version`. Capability claims describe the deployed API, not every feature of its underlying model family. The plugin sends the original model ID and never a translated display name.

For a service without this capability route, add a small service-side metadata adapter before using this client. The announcer alone is enough for DNS-SD discovery, but not for complete client interoperability. OpenAI Chat Completions, Ollama-native APIs, automatic credential enrollment and the entire Open Responses specification are not implemented by this release.

## Independent trust

Provision this file through a trusted local channel and set the plugin's `trustFile` to its path:

```json
{
  "schema": "llm-api-discovery-trust/v1",
  "caFile": "ca.pem",
  "services": [{
    "baseURL": "https://workstation.local:8443/v1",
    "allowedAddresses": ["192.168.1.50"],
    "certificateSha256": "REPLACE_WITH_SHA256_OF_LEAF_CERTIFICATE_DER",
    "tokenFile": "tokens/workstation.txt"
  }]
}
```

Paths resolve relative to the trust file. The API must use a certificate matching its advertised hostname. The plugin verifies the CA chain, hostname, leaf fingerprint, exact endpoint and independently approved IP. Tokens are read locally and sent only after this verification. DNS data cannot supply a token path, CA, fingerprint or permission to connect. Redirects are rejected. Private CA configuration is confined to this plugin's HTTPS agent.

## Demo compatibility

`demoMode: true` is an explicit integration setting for the separate demo repository. It selects the legacy `/_demo/capabilities` route, registers the fixed read-only `demo_read_marker` tool, and enables the Mock-only Host-context metadata convention. The default is false: ordinary installations register no demo tool and send no `demo_context_indices` metadata. The legacy capabilities/trust schema names remain accepted for existing deployments. Do not enable demo mode for unrelated production services.

Changing language changes only presentation. Addresses, protocol identifiers, model IDs, credentials and connection identity stay unchanged.
